const themeButton=document.querySelector('#case-theme');
const system=matchMedia('(prefers-color-scheme:dark)');
let chosen=null;try{chosen=localStorage.getItem('portfolio-theme')}catch{}
function applyTheme(value){document.documentElement.dataset.theme=value;themeButton.setAttribute('aria-label',value==='dark'?'Switch to light mode':'Switch to dark mode');themeButton.title=themeButton.getAttribute('aria-label');document.querySelector('meta[name="theme-color"]').content=value==='dark'?'#131a24':'#fcfcfb'}
applyTheme(chosen|| (system.matches?'dark':'light'));
themeButton.addEventListener('click',()=>{chosen=document.documentElement.dataset.theme==='dark'?'light':'dark';applyTheme(chosen);try{localStorage.setItem('portfolio-theme',chosen)}catch{}});
system.addEventListener('change',()=>{if(!chosen)applyTheme(system.matches?'dark':'light')});
const links=[...document.querySelectorAll('.case-toc a')];
const sections=links.map(link=>document.querySelector(link.getAttribute('href')));
function updateIndex(){let active=sections[0];for(const section of sections){if(section.getBoundingClientRect().top<=innerHeight*.3)active=section;}links.forEach(link=>{if(link.getAttribute('href')==='#'+active.id)link.setAttribute('aria-current','true');else link.removeAttribute('aria-current')})}
let scheduled=false;addEventListener('scroll',()=>{if(scheduled)return;scheduled=true;requestAnimationFrame(()=>{scheduled=false;updateIndex()})},{passive:true});updateIndex();
// Native disclosure stays compact on mobile; all section links remain available.
const contents=document.querySelector('.case-toc details');if(matchMedia('(max-width:700px)').matches)contents.open=false;
const imageDialog=document.querySelector('.case-image-dialog');let lastImageButton;
document.querySelectorAll('.case-zoom').forEach(button=>button.addEventListener('click',()=>{lastImageButton=button;const source=button.querySelector('img'),target=imageDialog.querySelector('img');target.src=source.src;target.alt=source.alt;imageDialog.showModal();document.body.classList.add('modal-open')}));
imageDialog.querySelector('.case-image-close').addEventListener('click',()=>imageDialog.close());
imageDialog.addEventListener('click',event=>{if(event.target!==imageDialog)return;const r=imageDialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)imageDialog.close()});
imageDialog.addEventListener('close',()=>{document.body.classList.remove('modal-open');lastImageButton?.focus()});
// The homepage's elastic divider, turned vertically for the reading layout.
const stringButton=document.querySelector('.case-vertical-string');
const stringPath=stringButton.querySelector('path');
const reducedMotion=matchMedia('(prefers-reduced-motion:reduce)');
let stringY=360,stringX=0,stringVelocity=0,stringTarget=0,stringFrame=0;
function paintString(){stringFrame=0;if(reducedMotion.matches){stringX=stringTarget;stringVelocity=0}else{stringVelocity+=(stringTarget-stringX)*.09;stringVelocity*=.82;stringX+=stringVelocity}stringPath.setAttribute('d',`M28 2C28 ${stringY*.36} ${28+stringX} ${stringY*.62} ${28+stringX} ${stringY}C${28+stringX} ${stringY+(720-stringY)*.38} 28 ${stringY+(720-stringY)*.64} 28 718`);if(!reducedMotion.matches&&(Math.abs(stringX-stringTarget)>.02||Math.abs(stringVelocity)>.02))stringFrame=requestAnimationFrame(paintString)}
function animateString(){if(!stringFrame)stringFrame=requestAnimationFrame(paintString)}
function pullString(event){const r=stringButton.getBoundingClientRect();stringY=Math.max(20,Math.min(700,(event.clientY-r.top)/r.height*720));stringTarget=Math.max(-19,Math.min(19,(event.clientX-r.left-r.width/2)*56/r.width));if(Math.abs(stringTarget)<4)stringTarget=stringTarget<0?-4:4;animateString()}
stringButton.addEventListener('pointerenter',pullString);stringButton.addEventListener('pointermove',pullString);stringButton.addEventListener('pointerleave',()=>{stringTarget=0;animateString()});stringButton.addEventListener('focus',()=>{stringTarget=7;animateString()});stringButton.addEventListener('blur',()=>{stringTarget=0;animateString()});stringButton.addEventListener('click',()=>{stringTarget=0;stringVelocity=12;animateString()});stringButton.addEventListener('keydown',event=>{if(event.key==='ArrowLeft'||event.key==='ArrowRight'){event.preventDefault();stringTarget=event.key==='ArrowLeft'?-16:16;animateString()}});stringButton.addEventListener('keyup',event=>{if(event.key==='ArrowLeft'||event.key==='ArrowRight'){stringTarget=0;animateString()}});
// Keep the string exactly midway between the navigation and article columns.
function positionCaseDivider(){if(!matchMedia('(min-width:1241px)').matches)return;const nav=document.querySelector('.case-toc').getBoundingClientRect(),article=document.querySelector('.case-hero').getBoundingClientRect();stringButton.style.left=((nav.right+article.left)/2-stringButton.getBoundingClientRect().width/2)+'px'}
addEventListener('resize',positionCaseDivider,{passive:true});document.fonts.ready.then(positionCaseDivider);positionCaseDivider();
