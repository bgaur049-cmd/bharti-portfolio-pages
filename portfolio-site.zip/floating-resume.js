(()=>{
 const resume=document.querySelector('body>.resume-download'),back=document.querySelector('.footer-back-top');
 if(!resume||!back)return;
 let frame=0;
 function update(){frame=0;const base=innerWidth<=700?258:72;const top=back.getBoundingClientRect().top;const bottom=Math.max(base,innerHeight-top+16);resume.style.bottom=bottom+'px';}
 function schedule(){if(!frame)frame=requestAnimationFrame(update);}
 addEventListener('scroll',schedule,{passive:true});addEventListener('resize',schedule);update();
})();
