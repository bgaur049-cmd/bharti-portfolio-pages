const avatar=document.querySelector('#avatar');
const names=['Normal','Sunglasses','Painter cap'];
let current=0,sound=true,audio;
const motion=window.matchMedia('(prefers-reduced-motion: reduce)');
function setLook(index,user=false){current=index;avatar.dataset.look=String(current);avatar.setAttribute('aria-label',`Change avatar look. Current look: ${names[current]}`);document.querySelectorAll('[data-look]').forEach(el=>{if(el!==avatar)el.setAttribute('aria-pressed',String(Number(el.dataset.look)===current))});}
avatar.addEventListener('click',()=>{setLook((current+1)%names.length,true);restartCycle()});
document.querySelectorAll('.looks button').forEach(button=>button.addEventListener('click',()=>{setLook(Number(button.dataset.look),true);restartCycle()}));
let cycle;function restartCycle(){clearInterval(cycle);if(!motion.matches&&!document.hidden)cycle=setInterval(()=>{if(!avatar.matches(':hover')&&document.activeElement!==avatar)setLook((current+1)%names.length)},5200)}
restartCycle();motion.addEventListener('change',restartCycle);document.addEventListener('visibilitychange',restartCycle);
setInterval(()=>{if(document.hidden||motion.matches||current===1)return;avatar.classList.add('blink');setTimeout(()=>avatar.classList.remove('blink'),140)},2000);
const dialog=document.querySelector('#project-dialog');let activeProject;
document.querySelectorAll('button.outcome-row').forEach(button=>button.addEventListener('click',()=>{activeProject=button;document.querySelector('#dialog-title').textContent=button.querySelector('.outcome-title').textContent;dialog.querySelector('.dialog-category').textContent=button.dataset.category;dialog.querySelector('.dialog-art').replaceChildren(button.querySelector('.case-thumbnail').cloneNode(true));dialog.showModal();document.body.classList.add('modal-open')}));
function closeDialog(){dialog.close()}
dialog.querySelector('.close').addEventListener('click',closeDialog);dialog.querySelector('.back-button').addEventListener('click',closeDialog);
dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)closeDialog()}});
dialog.addEventListener('close',()=>{document.body.classList.remove('modal-open');activeProject?.focus()});
const yearLabel=document.querySelector('#year');if(yearLabel)yearLabel.textContent=String(new Date().getFullYear());

const themeButton=document.querySelector('#theme');
const systemTheme=window.matchMedia('(prefers-color-scheme: dark)');
let chosenTheme=null;
try{chosenTheme=localStorage.getItem('portfolio-theme')}catch{}
function applyTheme(theme){document.documentElement.dataset.theme=theme;themeButton.setAttribute('aria-label',theme==='dark'?'Switch to light mode':'Switch to dark mode');themeButton.title=themeButton.getAttribute('aria-label');document.querySelector('meta[name="theme-color"]').setAttribute('content',theme==='dark'?'#152d50':'#9bc9ec')}
applyTheme(chosenTheme==='dark'||chosenTheme==='light'?chosenTheme:systemTheme.matches?'dark':'light');
themeButton.addEventListener('click',()=>{chosenTheme=document.documentElement.dataset.theme==='dark'?'light':'dark';applyTheme(chosenTheme);try{localStorage.setItem('portfolio-theme',chosenTheme)}catch{}});
systemTheme.addEventListener('change',()=>{if(!chosenTheme)applyTheme(systemTheme.matches?'dark':'light')});

// Springy blades, each reacting locally to the visitor's brush.
const grass=document.querySelector('.grass-divider');
const grassSurface=document.querySelector('#grass-surface');
const bladeGroup=document.querySelector('#grass-blades');
const blades=[];
let grassX=360,lastGrassX=360,grassInside=false,grassFocused=false,grassVisible=true,grassFrame=0,brushSpeed=0,brushDirection=1,grassLastFrame=0,sweepStart=-10000,sweepDirection=1;
let rustle=null,rustleBuffer=null,rustleTimer=null,lastRustleUpdate=0,brushQuietTimer=null;
function grassSeed(i){const n=Math.sin(i*127.1+31.7)*43758.5453;return n-Math.floor(n)}
for(let layer=0;layer<2;layer++)for(let i=0;i<91;i++){const n=i+layer*91,x=7+i*7.85+grassSeed(n)*5,height=17+grassSeed(n+310)*(layer?38:28),width=layer?1.6+grassSeed(n+31)*1.9:1.4+grassSeed(n+89)*1.7;const path=document.createElementNS('http://www.w3.org/2000/svg','path');path.setAttribute('class','grass-blade');path.setAttribute('fill',layer?(i%4?'var(--grass-front)':'var(--grass-mid)'):'var(--grass-back)');bladeGroup.append(path);blades.push({path,x,height,width,rest:(grassSeed(n+99)-.5)*17,bend:0,velocity:0,phase:grassSeed(n+30)*Math.PI*2,layer})}
function makeRustleBuffer(context){const buffer=context.createBuffer(1,context.sampleRate*5,context.sampleRate),out=buffer.getChannelData(0);let smooth=0;for(let i=0;i<out.length;i++){const white=Math.random()*2-1;smooth=.5*smooth+.5*white;out[i]=(white*.65+smooth*.35)*.32}return buffer}
function startRustle(){if(!sound||document.hidden)return;try{audio??=new(window.AudioContext||window.webkitAudioContext)();audio.resume().catch(()=>{});clearTimeout(rustleTimer);if(rustle)return;rustleBuffer??=makeRustleBuffer(audio);const source=audio.createBufferSource(),high=audio.createBiquadFilter(),low=audio.createBiquadFilter(),gain=audio.createGain();source.buffer=rustleBuffer;source.loop=true;high.type='highpass';high.frequency.value=1000;high.Q.value=.5;low.type='lowpass';low.frequency.value=3400;low.Q.value=.5;gain.gain.value=0;source.connect(high);high.connect(low);low.connect(gain);gain.connect(audio.destination);source.start(0,Math.random()*2);rustle={source,high,low,gain}}catch{}}
function stopRustle(){grass.classList.remove('is-brushing');brushSpeed=0;if(!rustle||!audio)return;rustle.gain.gain.cancelScheduledValues(audio.currentTime);rustle.gain.gain.setTargetAtTime(.00001,audio.currentTime,.08);const old=rustle;clearTimeout(rustleTimer);rustleTimer=setTimeout(()=>{if(rustle!==old)return;old.source.stop();old.source.disconnect();old.high.disconnect();old.low.disconnect();old.gain.disconnect();rustle=null},600)}
function paintGrass(now=0){grassFrame=0;const dt=Math.min(2,Math.max(.25,(now-grassLastFrame)/16.667||1));grassLastFrame=now;const sweeping=now-sweepStart<900;if(sweeping){grassX=sweepDirection>0?40+(now-sweepStart)/900*640:680-(now-sweepStart)/900*640;brushSpeed=.5;brushDirection=sweepDirection}const active=grassInside||sweeping||grassFocused;brushSpeed*=Math.pow(.87,dt);const moving=brushSpeed>.025;grass.classList.toggle('is-brushing',active&&moving);const t=motion.matches?0:now/1000;for(const blade of blades){const dist=blade.x-grassX,near=Math.exp(-dist*dist/3500),away=dist>=0?1:-1,target=active?near*(away*18+brushDirection*brushSpeed*32):0;if(motion.matches)blade.bend=target;else{blade.velocity+=(target-blade.bend)*.075*dt;blade.velocity*=Math.pow(.78,dt);blade.bend+=blade.velocity*dt}const breeze=motion.matches||!active?0:Math.sin(t*.7+blade.phase)*1.7,bend=blade.bend+breeze+blade.rest,x=blade.x,base=82+(blade.layer?grassSeed(x)*3:0),tipY=base-blade.height+Math.min(12,Math.abs(bend)*.15),tipX=x+bend,w=blade.width;blade.path.setAttribute('d',`M${(x-w/2).toFixed(2)} ${base.toFixed(2)}Q${(x+bend*.12-w/2).toFixed(2)} ${(base-blade.height*.58).toFixed(2)} ${tipX.toFixed(2)} ${tipY.toFixed(2)}Q${(x+bend*.48+w/2).toFixed(2)} ${(base-blade.height*.4).toFixed(2)} ${(x+w/2).toFixed(2)} ${base.toFixed(2)}Z`)}if(rustle&&audio&&now-lastRustleUpdate>40){const level=sound&&active?Math.min(.17,brushSpeed*.24):0;rustle.gain.gain.setTargetAtTime(level,audio.currentTime,level>.01?.025:.09);rustle.low.frequency.setTargetAtTime(2600+Math.min(1,brushSpeed)*2000,audio.currentTime,.06);lastRustleUpdate=now}if(motion.matches&&rustle){clearTimeout(brushQuietTimer);brushQuietTimer=setTimeout(()=>{if(rustle&&audio)rustle.gain.gain.setTargetAtTime(.00001,audio.currentTime,.08);grass.classList.remove('is-brushing')},160)}if(grassVisible&&!document.hidden&&!motion.matches)grassFrame=requestAnimationFrame(paintGrass)}
function animateGrass(){if(!grassFrame)paintGrass(performance.now())}
function brushAt(event){const rect=grassSurface.getBoundingClientRect();lastGrassX=grassX;grassX=Math.max(0,Math.min(720,(event.clientX-rect.left)/rect.width*720));const delta=grassX-lastGrassX;if(Math.abs(delta)>.2){brushDirection=Math.sign(delta);brushSpeed=Math.min(1.3,Math.abs(delta)/22);startRustle()}animateGrass()}
grassSurface.addEventListener('pointerenter',event=>{if(event.pointerType==='touch')return;grassInside=true;const rect=grassSurface.getBoundingClientRect();grassX=(event.clientX-rect.left)/rect.width*720;brushSpeed=.25;startRustle();animateGrass()});
grassSurface.addEventListener('pointermove',brushAt);
grassSurface.addEventListener('pointerleave',()=>{grassInside=false;stopRustle();animateGrass()});
grassSurface.addEventListener('focus',()=>{grassFocused=true;animateGrass()});
grassSurface.addEventListener('blur',()=>{grassFocused=false;if(!grassInside)stopRustle();animateGrass()});
grassSurface.addEventListener('click',()=>{sweepStart=performance.now();sweepDirection*=-1;startRustle();animateGrass()});
grassSurface.addEventListener('keydown',event=>{if(event.key==='ArrowLeft'||event.key==='ArrowRight'){event.preventDefault();brushDirection=event.key==='ArrowLeft'?-1:1;grassX=Math.max(0,Math.min(720,grassX+brushDirection*50));brushSpeed=.8;startRustle();animateGrass()}});
new IntersectionObserver(entries=>{grassVisible=entries[0].isIntersecting;if(grassVisible)animateGrass();else{cancelAnimationFrame(grassFrame);grassFrame=0;stopRustle()}},{rootMargin:'80px'}).observe(grass);
document.addEventListener('visibilitychange',()=>{if(document.hidden){stopRustle();cancelAnimationFrame(grassFrame);grassFrame=0}else if(grassVisible)animateGrass()});
motion.addEventListener('change',()=>{cancelAnimationFrame(grassFrame);grassFrame=0;animateGrass()});
function unlockGrassAudio(){if(!sound)return;try{audio??=new(window.AudioContext||window.webkitAudioContext)();audio.resume().then(()=>{if(grassInside&&brushSpeed>.03)startRustle()}).catch(()=>{})}catch{}}
document.addEventListener('pointerdown',unlockGrassAudio,{capture:true,passive:true});document.addEventListener('keydown',unlockGrassAudio,{capture:true});
animateGrass();

// A fine line that follows a brush and springs back after a pluck.
document.querySelectorAll('.loose-string').forEach(button=>{const path=button.querySelector('path');let x=360,y=0,velocity=0,target=0,frame=0;function paint(){frame=0;if(motion.matches){y=target;velocity=0}else{velocity+=(target-y)*.09;velocity*=.82;y+=velocity}path.setAttribute('d',`M2 28C${(x*.36).toFixed(1)} 28 ${(x*.62).toFixed(1)} ${(28+y).toFixed(2)} ${x.toFixed(1)} ${(28+y).toFixed(2)}C${(x+(720-x)*.38).toFixed(1)} ${(28+y).toFixed(2)} ${(x+(720-x)*.64).toFixed(1)} 28 718 28`);if(!motion.matches&&(Math.abs(y-target)>.02||Math.abs(velocity)>.02))frame=requestAnimationFrame(paint)}function animate(){if(!frame)frame=requestAnimationFrame(paint)}function pull(event){const rect=button.getBoundingClientRect();x=Math.max(20,Math.min(700,(event.clientX-rect.left)/rect.width*720));target=Math.max(-20,Math.min(20,event.clientY-rect.top-rect.height/2));if(Math.abs(target)<4)target=target<0?-4:4;animate()}button.addEventListener('pointerenter',pull);button.addEventListener('pointermove',pull);button.addEventListener('pointerleave',()=>{target=0;animate()});button.addEventListener('focus',()=>{target=7;animate()});button.addEventListener('blur',()=>{target=0;animate()});button.addEventListener('click',()=>{target=0;velocity=12;animate()});button.addEventListener('keydown',event=>{if(event.key==='ArrowUp'||event.key==='ArrowDown'){event.preventDefault();target=event.key==='ArrowUp'?-16:16;animate()}});button.addEventListener('keyup',event=>{if(event.key==='ArrowUp'||event.key==='ArrowDown'){target=0;animate()}})});


// Match full-bleed grass to the viewport excluding its scrollbar.
function sizeGrassViewport(){document.documentElement.style.setProperty("--grass-viewport",document.documentElement.clientWidth+"px")}
sizeGrassViewport();addEventListener("resize",sizeGrassViewport,{passive:true});

