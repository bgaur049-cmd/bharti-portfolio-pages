/* One isolated cricket chirp for buttons, links, and cards on portfolio pages. */
(()=>{
 const source=new URL('assets/ui-click-chirp.wav',document.currentScript.src).href;
 const clips=Array.from({length:4},()=>{
  const clip=document.createElement('audio');
  clip.className='interaction-click-audio';clip.src=source;clip.preload='auto';clip.volume=.55;
  clip.hidden=true;clip.setAttribute('aria-hidden','true');document.body.append(clip);return clip;
 });
 let index=0,lastClick=-1000;
 document.addEventListener('click',event=>{
  const target=event.target instanceof Element?event.target.closest('button,a,summary'):null;
  if(!target||target.matches(':disabled,[aria-disabled="true"],.skip')||target.closest('.grass-surface,.loose-string,.case-vertical-string'))return;
  const now=performance.now();if(now-lastClick<65)return;lastClick=now;
  const clip=clips[index++%clips.length];clip.currentTime=0;clip.play().catch(()=>{});
  // Let the short chirp finish before a same-tab page navigation unloads it.
  if(target.tagName==='A'&&!target.hasAttribute('data-password-popup')&&!event.defaultPrevented&&!target.hasAttribute('download')&&(!target.target||target.target==='_self')&&!event.metaKey&&!event.ctrlKey&&!event.shiftKey&&!event.altKey&&event.button===0){
   const url=new URL(target.href,location.href);
   if(url.origin===location.origin&&(url.pathname!==location.pathname||url.search!==location.search)){
    event.preventDefault();setTimeout(()=>{location.href=url.href},180);
   }
  }
 },{capture:true});
})();
