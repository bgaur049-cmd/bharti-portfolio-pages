(() => {
  const grass = document.querySelector('.grass-divider');
  const surface = document.querySelector('#grass-surface');
  if (!grass || !surface) return;
  const field = document.createElement('div');
  field.className = 'firefly-field';
  field.setAttribute('aria-hidden', 'true');
  grass.append(field);
  new MutationObserver(() => {field.replaceChildren()}).observe(document.documentElement, {attributes:true,attributeFilter:['data-theme']});
  let energy = 0, lastTime = 0, lastX = null, lastRelease = -10000;
  function stir(amount, clientX) {
    const now = performance.now();
    energy = Math.max(0, energy - (now - lastTime) * .06) + amount;
    lastTime = now;
    const night = document.documentElement.dataset.theme === 'dark';
    if (energy < (night ? 320 : 70) || now - lastRelease < (night ? 1700 : 5000) || (night ? field.childElementCount > 14 : field.childElementCount > 0)) return;
    energy = 0;
    lastRelease = now;
    const rect = surface.getBoundingClientRect();
    const center = clientX == null ? rect.width / 2 : clientX - rect.left;
    const chance = Math.random();
    const count = night ? 7 : chance < .2 ? 1 : chance < .75 ? 2 : 3;
    const groupDirection = Math.random() < .5 ? -1 : 1;
    for (let i = 0; i < count; i++) {
      const fly = document.createElement('span');
      fly.className = night ? 'firefly' : 'butterfly';
      if (!night) {
        fly.style.setProperty('--wing-color', ['#df9645','#5eadd4','#aa91cd'][Math.floor(Math.random()*3)]);
        fly.style.setProperty('--flap', (.24 + Math.random() * .14) + 's');
        const direction = groupDirection * (i % 2 ? -1 : 1);
        const distance = 100 + Math.random() * 220;
        const rise = 190 + Math.random() * 150;
        const turn = (Math.random() - .5) * 90;
        [ [.18,.22], [.48,.4], [.35,.66], [1,.86] ].forEach(([dx,dy],step)=>{
          fly.style.setProperty('--x'+(step+1), (direction * distance * dx + (Math.random()-.5)*80) + 'px');
          fly.style.setProperty('--y'+(step+1), (-rise * dy) + 'px');
        });
        fly.style.setProperty('--end-x', direction * distance + 'px');
        fly.style.setProperty('--end-y', -rise + 'px');
        fly.style.setProperty('--bank', turn + 'deg');

        const wing = '<path class="wing-outline" d="M15 14H13V11H11V8H8V6H3V7H2V12H3V15H5V17H4V21H6V24H10V23H12V20H14V18H15Z"/><path class="wing-fill" d="M14 14H12V12H10V9H7V8H4V12H5V14H8V16H14ZM13 18H8V19H6V21H7V22H10V21H12Z"/><path class="wing-veins" d="M13 15H10V13H8V11H5M12 19H10V21M8 17H5"/><path class="wing-specks" d="M4 9h2v1H4ZM6 20h1v1H6ZM8 22h1v1H8Z"/>';
        fly.innerHTML = '<svg viewBox="0 0 32 28" shape-rendering="crispEdges" aria-hidden="true"><g class="butterfly-wing left-wing">'+wing+'</g><g class="butterfly-wing right-wing"><g transform="translate(32 0) scale(-1 1)">'+wing+'</g></g><path fill="#383e37" d="M15 10h2v13h-2ZM14 9h4v3h-4ZM12 5h1v2h1v2h-1V7h-1ZM19 5h1v2h-1v2h-1V7h1Z"/><path fill="#778578" d="M15 13h1v7h-1Z"/></svg>' ;
      }
      const x = Math.max(20, Math.min(rect.width - 20, center + (Math.random() - .5) * 210));
      fly.style.setProperty('--start', x + 'px');
      fly.style.setProperty('--flight', (7 + Math.random() * 2) + 's');
      fly.style.setProperty('--drift-a', (Math.random() - .5) * 110 + 'px');
      fly.style.setProperty('--drift-b', (Math.random() - .5) * 150 + 'px');
      fly.style.animationDelay = i * .09 + 's';
      field.append(fly);
      fly.addEventListener('animationend', () => fly.remove(), {once:true});
    }
  }
  surface.addEventListener('pointerenter', e => {lastX = e.clientX});
  surface.addEventListener('pointermove', e => {
    if(lastX != null) stir(Math.min(80, Math.abs(e.clientX - lastX)), e.clientX);
    lastX = e.clientX;
  });
  surface.addEventListener('pointerleave', () => {lastX = null});
  surface.addEventListener('click', e => stir(120, e.detail ? e.clientX : null));
  surface.addEventListener('keydown', e => {
    if(e.key === 'ArrowLeft' || e.key === 'ArrowRight') stir(100);
  });
})();
