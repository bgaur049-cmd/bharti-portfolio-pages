const commentDialog=document.querySelector('.comment-image-dialog');
let commentTrigger;
document.querySelectorAll('.comment-expand').forEach(button=>button.addEventListener('click',()=>{
 commentTrigger=button;
 const original=button.closest('.live-comment');
 const card=original.cloneNode(true);
 card.querySelector('.comment-expand')?.remove();
 card.removeAttribute('aria-labelledby');
 card.querySelectorAll('[id]').forEach(el=>el.removeAttribute('id'));
 commentDialog.querySelector('.comment-dialog-content').replaceChildren(card);
 commentDialog.setAttribute('aria-label',original.dataset.comment==='felix'?'Felix Lee’s comment':'James Badour’s comment');
 commentDialog.showModal();
}));
commentDialog.querySelector('.comment-image-close').addEventListener('click',()=>commentDialog.close());
commentDialog.addEventListener('click',event=>{if(event.target!==commentDialog)return;const rect=commentDialog.getBoundingClientRect();if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)commentDialog.close();});
commentDialog.addEventListener('close',()=>commentTrigger?.focus());
