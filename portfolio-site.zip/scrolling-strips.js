const reduceStripMotion = matchMedia('(prefers-reduced-motion: reduce)');
const narrowStrips = matchMedia('(max-width: 700px)');

for (const strip of document.querySelectorAll('.shots-row, .personal-photo-strip')) {
  const group = strip.firstElementChild.firstElementChild;
  const reverse = strip.classList.contains('shots-row-2');
  const photos = strip.classList.contains('personal-photo-strip');
  const speeds = photos ? [28, 28] : reverse ? [25, 23] : [28, 26];
  let span = 0;
  let canLoop = false;
  let visible = false;
  let hovering = false;
  let touching = false;
  let drag;
  let suppressClick = false;
  let resumeAt = 0;
  let frame = 0;
  let lastTime = 0;
  let remainder = 0;
  let lastAutomaticPosition = strip.scrollLeft;

  function pause() {
    resumeAt = performance.now() + 650;
    lastTime = 0;
    remainder = 0;
  }

  function setAutomaticPosition(position) {
    strip.scrollLeft = position;
    lastAutomaticPosition = strip.scrollLeft;
  }

  function animate(now) {
    frame = 0;
    const active = !hovering && !touching && !drag && now >= resumeAt
      && !strip.matches(':focus-visible, :has(:focus-visible)');

    if (active && lastTime) {
      const speed = speeds[Number(narrowStrips.matches)];
      remainder += Math.min(now - lastTime, 50) * speed / 1000;
      const distance = Math.floor(remainder);
      if (distance) {
        remainder -= distance;
        const position = strip.scrollLeft + (reverse ? -distance : distance);
        setAutomaticPosition(((position % span) + span) % span);
      }
    }
    lastTime = active ? now : 0;
    schedule();
  }

  function schedule() {
    if (frame || !visible || !canLoop || reduceStripMotion.matches || document.hidden) return;
    frame = requestAnimationFrame(animate);
  }

  function measure() {
    const previousSpan = span;
    span = group.offsetWidth;
    canLoop = span > strip.clientWidth;
    if (canLoop && !previousSpan && reverse && !reduceStripMotion.matches) {
      setAutomaticPosition(span - 1);
    }
    cancelAnimationFrame(frame);
    frame = 0;
    lastTime = 0;
    schedule();
  }

  const sizes = new ResizeObserver(measure);
  sizes.observe(strip);
  sizes.observe(group);
  new IntersectionObserver(([entry]) => {
    visible = entry.isIntersecting;
    measure();
  }).observe(strip);
  reduceStripMotion.addEventListener('change', measure);
  document.addEventListener('visibilitychange', measure);

  strip.addEventListener('scroll', () => {
    if (Math.abs(strip.scrollLeft - lastAutomaticPosition) > 0.5) pause();
  }, { passive: true });

  strip.addEventListener('wheel', event => {
    if (event.ctrlKey || (!event.deltaX && !event.shiftKey)) return;
    pause();
    if (!event.deltaX && event.shiftKey && event.deltaY) {
      const scale = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? strip.clientWidth : 1;
      strip.scrollLeft += event.deltaY * scale;
      event.preventDefault();
    }
  }, { passive: false });

  strip.addEventListener('pointerenter', event => {
    hovering = event.pointerType === 'mouse' || event.pointerType === 'pen';
  });
  strip.addEventListener('pointerleave', () => { hovering = false; });

  strip.addEventListener('pointerdown', event => {
    if (!event.isPrimary || event.button !== 0) return;
    pause();
    suppressClick = false;
    if (event.pointerType === 'touch') {
      touching = true;
      return;
    }
    drag = { id: event.pointerId, x: event.clientX, start: strip.scrollLeft };
  });

  strip.addEventListener('pointermove', event => {
    if (drag?.id !== event.pointerId) return;
    const distance = event.clientX - drag.x;
    if (!suppressClick && Math.abs(distance) < 6) return;
    if (!suppressClick) {
      suppressClick = true;
      strip.setPointerCapture(event.pointerId);
      strip.classList.add('is-dragging');
    }
    strip.scrollLeft = drag.start - distance;
  });

  function endGesture(event) {
    if (touching && event.pointerType === 'touch' && event.isPrimary) {
      touching = false;
      pause();
    }
    if (drag?.id !== event.pointerId) return;
    drag = undefined;
    strip.classList.remove('is-dragging');
    pause();
  }

  strip.addEventListener('pointercancel', endGesture);
  strip.addEventListener('lostpointercapture', endGesture);
  window.addEventListener('pointerup', endGesture);
  strip.addEventListener('dragstart', event => event.preventDefault());
  strip.addEventListener('click', event => {
    if (!suppressClick || event.detail === 0) return;
    suppressClick = false;
    event.preventDefault();
    event.stopPropagation();
  }, true);
}
