/* Shared hover audio for buttons, links and cards, including dialog controls. */
(()=>{
 const source=new URL('assets/ui-hover-soft.mp3',document.currentScript.src).href;
 const clips=Array.from({length:4},()=>{const clip=new Audio(source);clip.preload='auto';clip.volume=.4;return clip;});
 let index=0,last=-1000;
 const selector='button,a,[role="button"],.outcome-row';
 function eligible(target){return target&&!target.matches(':disabled,[aria-disabled="true"],.skip')&&!target.closest('.loose-string,.case-vertical-string,.grass-surface');}
 function play(){if(document.hidden)return;const now=performance.now();if(now-last<85)return;last=now;const clip=clips[index++%clips.length];clip.currentTime=0;clip.play().catch(()=>{});}
 document.addEventListener('pointerover',event=>{if(event.pointerType==='touch'||!(event.target instanceof Element))return;const target=event.target.closest(selector);if(!eligible(target))return;if(event.relatedTarget instanceof Node&&target.contains(event.relatedTarget))return;play();});
 document.addEventListener('focusin',event=>{if(!(event.target instanceof Element))return;const target=event.target.closest(selector);if(eligible(target)&&target.matches(':focus-visible'))play();});
})();
